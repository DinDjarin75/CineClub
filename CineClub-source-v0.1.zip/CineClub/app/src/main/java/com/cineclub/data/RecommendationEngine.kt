package com.cineclub.data

import com.cineclub.model.*
import kotlin.math.ln

object RecommendationEngine {
    private val moodGenres = mapOf(
        Mood.WEIRD to setOf("horror", "science-fiction", "fantasy", "mystery", "animation"),
        Mood.BRUTAL to setOf("horror", "action", "crime", "thriller"),
        Mood.TENSE to setOf("thriller", "crime", "mystery", "horror"),
        Mood.FUNNY to setOf("comedy"),
        Mood.BEAUTIFUL to setOf("drama", "romance", "fantasy", "animation"),
        Mood.MINDFUCK to setOf("mystery", "science-fiction", "thriller", "horror"),
        Mood.COMFORT to setOf("comedy", "family", "animation", "romance")
    )

    fun rank(candidates: List<MediaCandidate>, prefs: WatchPreferences): List<Recommendation> {
        val allowed = candidates
            .distinctBy { "${it.kind}:${it.traktId ?: it.title}:${it.season}:${it.episode}" }
            .filter { c ->
                when (prefs.format) {
                    FormatChoice.MOVIE -> c.kind == MediaKind.MOVIE
                    FormatChoice.EPISODE -> c.kind == MediaKind.EPISODE
                    FormatChoice.EITHER -> true
                }
            }
            .filter { c -> prefs.time.maxMinutes == null || c.runtimeMinutes == null || c.runtimeMinutes <= prefs.time.maxMinutes }

        val scored = allowed.map { c ->
            var score = (c.rating.coerceIn(0.0, 10.0) * 6.0) + ln((c.votes + 10).toDouble()) * 2.0
            val targets = moodGenres[prefs.mood].orEmpty()
            val matches = c.genres.count { it in targets }
            score += matches * 14.0
            if (c.overview.orEmpty().contains(prefs.mood.label, ignoreCase = true)) score += 5.0
            score += when (c.source) {
                CandidateSource.CONTINUE -> if (prefs.mode == WatchMode.CONTINUE) 34.0 else 3.0
                CandidateSource.PLAYBACK -> if (prefs.mode == WatchMode.CONTINUE) 38.0 else 2.0
                CandidateSource.WATCHLIST -> if (prefs.mode == WatchMode.BLIND_SPOT) 32.0 else 5.0
                CandidateSource.REWATCH -> if (prefs.mode == WatchMode.REWATCH) 30.0 else 0.0
                CandidateSource.TRENDING -> if (prefs.mode == WatchMode.DISCOVERY) 18.0 else 0.0
            }
            if (prefs.time.maxMinutes != null && c.runtimeMinutes != null) {
                val distance = prefs.time.maxMinutes - c.runtimeMinutes
                if (distance in 0..25) score += 8.0
            }
            Recommendation(c, score, why(c, prefs, matches), risk(c, prefs))
        }.sortedByDescending { it.score }

        if (prefs.format != FormatChoice.EITHER) return scored.take(3)

        // For Either, avoid three nearly identical answers when both formats are available.
        val movie = scored.firstOrNull { it.candidate.kind == MediaKind.MOVIE }
        val episode = scored.firstOrNull { it.candidate.kind == MediaKind.EPISODE }
        val chosen = mutableListOf<Recommendation>()
        listOfNotNull(movie, episode).sortedByDescending { it.score }.forEach { if (chosen.size < 2) chosen += it }
        scored.forEach { if (chosen.size < 3 && it !in chosen) chosen += it }
        return chosen.take(3)
    }

    private fun why(c: MediaCandidate, prefs: WatchPreferences, matches: Int): String {
        val pieces = mutableListOf<String>()
        when (c.source) {
            CandidateSource.CONTINUE -> pieces += "It is the next episode in something you already started."
            CandidateSource.PLAYBACK -> pieces += "You already have this in progress."
            CandidateSource.WATCHLIST -> pieces += "It is sitting in your Trakt watchlist instead of being another random discovery."
            CandidateSource.REWATCH -> pieces += "You have watched it before, making it a deliberate rewatch candidate."
            CandidateSource.TRENDING -> pieces += "It is a fresh discovery candidate from current Trakt activity."
        }
        if (matches > 0) pieces += "Its genres line up with your ${prefs.mood.label.lowercase()} mood."
        c.runtimeMinutes?.let { pieces += "At $it minutes it fits tonight's time window." }
        if (prefs.company != Company.ALONE) pieces += "Company is set to ${prefs.company.label}; personal taste profiles come in the next build."
        return pieces.joinToString(" ")
    }

    private fun risk(c: MediaCandidate, prefs: WatchPreferences): String = when {
        c.rating in 0.1..6.4 -> "Lower community rating than the other picks — this is the gamble."
        prefs.time.maxMinutes != null && c.runtimeMinutes == null -> "Runtime is missing, so the time fit is uncertain."
        c.genres.isEmpty() -> "Sparse metadata means this pick is based more on activity than taste matching."
        c.source == CandidateSource.TRENDING -> "Popular does not automatically mean interesting — treat this as the wildcard."
        else -> "Low-risk match based on the data currently available."
    }
}
