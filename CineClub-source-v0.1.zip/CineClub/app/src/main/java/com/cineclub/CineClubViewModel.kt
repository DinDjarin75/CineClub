package com.cineclub

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cineclub.data.RecommendationEngine
import com.cineclub.data.SessionStore
import com.cineclub.data.TraktApi
import com.cineclub.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class CineClubUiState(
    val clientId: String = "",
    val connected: Boolean = false,
    val connectedUser: String? = null,
    val deviceCode: DeviceCode? = null,
    val authBusy: Boolean = false,
    val loading: Boolean = false,
    val error: String? = null,
    val preferences: WatchPreferences = WatchPreferences(),
    val recommendations: List<Recommendation> = emptyList(),
    val selectedIndex: Int = 0
)

class CineClubViewModel(app: Application) : AndroidViewModel(app) {
    private val store = SessionStore(app)
    private val api = TraktApi()
    private val _state = MutableStateFlow(
        CineClubUiState(
            clientId = store.clientId.orEmpty(),
            connected = !store.accessToken.isNullOrBlank()
        )
    )
    val state: StateFlow<CineClubUiState> = _state.asStateFlow()
    private var authJob: Job? = null

    init {
        if (_state.value.connected) refreshConnectedUser()
    }

    fun setClientId(value: String) {
        _state.value = _state.value.copy(clientId = value.trim(), error = null)
    }

    fun beginConnect() {
        val clientId = _state.value.clientId.trim()
        if (clientId.isBlank()) {
            _state.value = _state.value.copy(error = "Paste the Trakt Client ID first.")
            return
        }
        authJob?.cancel()
        authJob = viewModelScope.launch {
            _state.value = _state.value.copy(authBusy = true, error = null, deviceCode = null)
            runCatching { api.requestDeviceCode(clientId) }
                .onSuccess { code ->
                    store.clientId = clientId
                    _state.value = _state.value.copy(deviceCode = code)
                    runCatching { api.pollForToken(clientId, code) }
                        .onSuccess { token ->
                            store.accessToken = token.accessToken
                            store.refreshToken = token.refreshToken
                            _state.value = _state.value.copy(connected = true, deviceCode = null, authBusy = false)
                            refreshConnectedUser()
                        }
                        .onFailure { e -> _state.value = _state.value.copy(authBusy = false, error = e.message) }
                }
                .onFailure { e -> _state.value = _state.value.copy(authBusy = false, error = e.message) }
        }
    }

    fun disconnect() {
        store.clearAuth()
        authJob?.cancel()
        _state.value = _state.value.copy(connected = false, connectedUser = null, recommendations = emptyList(), deviceCode = null, authBusy = false)
    }

    fun setPreferences(value: WatchPreferences) {
        _state.value = _state.value.copy(preferences = value, error = null)
    }

    fun chooseTonight() {
        val clientId = store.clientId ?: _state.value.clientId
        val token = store.accessToken
        if (clientId.isBlank() || token.isNullOrBlank()) {
            _state.value = _state.value.copy(error = "Connect Trakt first.")
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            runCatching {
                val candidates = api.loadCandidates(clientId, token, _state.value.preferences)
                RecommendationEngine.rank(candidates, _state.value.preferences)
            }.onSuccess { recs ->
                _state.value = _state.value.copy(
                    loading = false,
                    recommendations = recs,
                    selectedIndex = 0,
                    error = if (recs.size < 3) "Only ${recs.size} strong match(es) available for these filters." else null
                )
            }.onFailure { e ->
                if (e.message?.contains("expired", true) == true) store.clearAuth()
                _state.value = _state.value.copy(loading = false, connected = !store.accessToken.isNullOrBlank(), error = e.message ?: "Could not load recommendations.")
            }
        }
    }

    fun select(index: Int) {
        _state.value = _state.value.copy(selectedIndex = index.coerceIn(0, (_state.value.recommendations.size - 1).coerceAtLeast(0)))
    }

    private fun refreshConnectedUser() {
        val clientId = store.clientId ?: return
        val token = store.accessToken ?: return
        viewModelScope.launch {
            runCatching { api.connectedUser(clientId, token) }
                .onSuccess { user -> _state.value = _state.value.copy(connectedUser = user) }
        }
    }
}
