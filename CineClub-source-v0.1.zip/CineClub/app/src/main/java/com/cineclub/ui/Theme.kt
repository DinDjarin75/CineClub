package com.cineclub.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Purple = Color(0xFFB56CFF)
val PurpleSoft = Color(0xFF8F52C7)
val Glass = Color(0xFF141117)
val Glass2 = Color(0xFF1B151F)
val Muted = Color(0xFFAAA2AF)

private val CineColors = darkColorScheme(
    primary = Purple,
    secondary = PurpleSoft,
    background = Color.Black,
    surface = Glass,
    onPrimary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun CineClubTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = CineColors, content = content)
}
