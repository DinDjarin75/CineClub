package com.cineclub.data

import com.cineclub.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class TraktApi {
    private val baseUrl = "https://api.trakt.tv"

    suspend fun requestDeviceCode(clientId: String): DeviceCode = withContext(Dispatchers.IO) {
        val body = JSONObject().put("client_id", clientId)
        val res = request("POST", "/oauth/device/code", clientId, null, body)
        val json = JSONObject(res.body)
        DeviceCode(
            deviceCode = json.getString("device_code"),
            userCode = json.getString("user_code"),
            verificationUrl = json.getString("verification_url"),
            expiresIn = json.optInt("expires_in", 600),
            interval = json.optInt("interval", 5)
        )
    }

    suspend fun pollForToken(clientId: String, code: DeviceCode): TraktToken = withContext(Dispatchers.IO) {
        val started = System.currentTimeMillis()
        var intervalSeconds = code.interval.coerceAtLeast(3)
        while ((System.currentTimeMillis() - started) < code.expiresIn * 1000L) {
            val body = JSONObject().put("code", code.deviceCode).put("client_id", clientId)
            val res = request("POST", "/oauth/device/token", clientId, null, body, allowError = true)
            when (res.code) {
                200 -> {
                    val json = JSONObject(res.body)
                    return@withContext TraktToken(json.getString("access_token"), json.optString("refresh_token").takeIf { it.isNotBlank() })
                }
                400, 404 -> Unit // authorization still pending / not found yet
                409 -> throw IllegalStateException("That Trakt device code has already been used.")
                410 -> throw IllegalStateException("The Trakt device code expired. Start again.")
                418 -> throw IllegalStateException("Trakt authorization was declined.")
                429 -> intervalSeconds += 2
                else -> if (res.code >= 500) Unit else throw IllegalStateException("Trakt authorization failed (${res.code}).")
            }
            delay(intervalSeconds * 1000L)
        }
        throw IllegalStateException("Trakt authorization timed out. Start again.")
    }

    suspend fun loadCandidates(clientId: String, token: String, prefs: WatchPreferences): List<MediaCandidate> = coroutineScope {
        val trendingMovies = async { runCatching { trendingMovies(clientId, token) }.getOrDefault(emptyList()) }
        val trendingShows = async { runCatching { trendingShows(clientId, token) }.getOrDefault(emptyList()) }
        val modeSpecific = async {
            runCatching {
                when (prefs.mode) {
                    WatchMode.DISCOVERY -> emptyList()
                    WatchMode.BLIND_SPOT -> watchlist(clientId, token)
                    WatchMode.REWATCH -> recentHistory(clientId, token)
                    WatchMode.CONTINUE -> continueWatching(clientId, token)
                }
            }.getOrDefault(emptyList())
        }
        val watchedMovies = async { runCatching { watchedIds(clientId, token, "movies") }.getOrDefault(emptySet()) }
        val watchedShows = async { runCatching { watchedIds(clientId, token, "shows") }.getOrDefault(emptySet()) }

        val specific = modeSpecific.await()
        val watchedMovieIds = watchedMovies.await()
        val watchedShowIds = watchedShows.await()
        val discovery = buildList {
            addAll(trendingMovies.await().filter { it.traktId !in watchedMovieIds })
            addAll(trendingShows.await().filter { it.traktId !in watchedShowIds })
        }
        (specific + discovery).distinctBy { "${it.kind}:${it.traktId}:${it.season}:${it.episode}" }
    }

    suspend fun connectedUser(clientId: String, token: String): String? = withContext(Dispatchers.IO) {
        val res = request("GET", "/users/settings", clientId, token)
        val user = JSONObject(res.body).optJSONObject("user") ?: return@withContext null
        user.optString("username").ifBlank { user.optString("name") }.takeIf { it.isNotBlank() }
    }

    private suspend fun trendingMovies(clientId: String, token: String): List<MediaCandidate> = withContext(Dispatchers.IO) {
        val res = request("GET", "/movies/trending?limit=30&extended=full", clientId, token)
        val arr = JSONArray(res.body)
        (0 until arr.length()).mapNotNull { i -> parseMovie(arr.optJSONObject(i)?.optJSONObject("movie"), CandidateSource.TRENDING) }
    }

    private suspend fun trendingShows(clientId: String, token: String): List<MediaCandidate> = withContext(Dispatchers.IO) {
        val res = request("GET", "/shows/trending?limit=30&extended=full", clientId, token)
        val arr = JSONArray(res.body)
        (0 until arr.length()).mapNotNull { i -> parseShowAsEpisodeLike(arr.optJSONObject(i)?.optJSONObject("show"), CandidateSource.TRENDING) }
    }

    private suspend fun watchlist(clientId: String, token: String): List<MediaCandidate> = coroutineScope {
        val movies = async {
            val r = request("GET", "/sync/watchlist/movies?limit=50&extended=full", clientId, token)
            val a = JSONArray(r.body)
            (0 until a.length()).mapNotNull { i -> parseMovie(a.optJSONObject(i)?.optJSONObject("movie"), CandidateSource.WATCHLIST) }
        }
        val shows = async {
            val r = request("GET", "/sync/watchlist/shows?limit=50&extended=full", clientId, token)
            val a = JSONArray(r.body)
            (0 until a.length()).mapNotNull { i -> parseShowAsEpisodeLike(a.optJSONObject(i)?.optJSONObject("show"), CandidateSource.WATCHLIST) }
        }
        movies.await() + shows.await()
    }

    private suspend fun recentHistory(clientId: String, token: String): List<MediaCandidate> = coroutineScope {
        val movies = async {
            val r = request("GET", "/users/me/history/movies?limit=40&extended=full", clientId, token)
            val a = JSONArray(r.body)
            (0 until a.length()).mapNotNull { i -> parseMovie(a.optJSONObject(i)?.optJSONObject("movie"), CandidateSource.REWATCH) }
        }
        val episodes = async {
            val r = request("GET", "/users/me/history/episodes?limit=40&extended=full", clientId, token)
            val a = JSONArray(r.body)
            (0 until a.length()).mapNotNull { i -> parseHistoryEpisode(a.optJSONObject(i), CandidateSource.REWATCH) }
        }
        movies.await() + episodes.await()
    }

    private suspend fun continueWatching(clientId: String, token: String): List<MediaCandidate> = coroutineScope {
        val playbackMovies = async {
            val r = request("GET", "/sync/playback/movies?limit=25&extended=full", clientId, token)
            val a = JSONArray(r.body)
            (0 until a.length()).mapNotNull { i ->
                val obj = a.optJSONObject(i) ?: return@mapNotNull null
                parseMovie(obj.optJSONObject("movie"), CandidateSource.PLAYBACK)?.copy(progress = obj.optDouble("progress").takeIf { !it.isNaN() })
            }
        }
        val playbackEpisodes = async {
            val r = request("GET", "/sync/playback/episodes?limit=25&extended=full", clientId, token)
            val a = JSONArray(r.body)
            (0 until a.length()).mapNotNull { i -> parsePlaybackEpisode(a.optJSONObject(i)) }
        }
        val nextEpisodes = async { nextEpisodes(clientId, token) }
        playbackMovies.await() + playbackEpisodes.await() + nextEpisodes.await()
    }

    private suspend fun nextEpisodes(clientId: String, token: String): List<MediaCandidate> = withContext(Dispatchers.IO) {
        val history = request("GET", "/users/me/history/episodes?limit=20&extended=full", clientId, token)
        val arr = JSONArray(history.body)
        val shows = LinkedHashMap<Long, JSONObject>()
        for (i in 0 until arr.length()) {
            val show = arr.optJSONObject(i)?.optJSONObject("show") ?: continue
            val id = show.optJSONObject("ids")?.optLong("trakt") ?: 0L
            if (id > 0) shows.putIfAbsent(id, show)
            if (shows.size >= 6) break
        }
        val out = mutableListOf<MediaCandidate>()
        for ((id, show) in shows) {
            val progress = runCatching { request("GET", "/shows/$id/progress/watched?extended=full", clientId, token) }.getOrNull() ?: continue
            val next = JSONObject(progress.body).optJSONObject("next_episode") ?: continue
            val showTitle = show.optString("title")
            val showSlug = show.optJSONObject("ids")?.optString("slug")
            val images = poster(show)
            val episodeTitle = next.optString("title").ifBlank { "Next episode" }
            out += MediaCandidate(
                kind = MediaKind.EPISODE,
                title = showTitle,
                year = show.optInt("year").takeIf { it > 0 },
                subtitle = "S${next.optInt("season")}E${next.optInt("number")} · $episodeTitle",
                runtimeMinutes = next.optInt("runtime").takeIf { it > 0 } ?: show.optInt("runtime").takeIf { it > 0 },
                genres = stringSet(show.optJSONArray("genres")),
                rating = show.optDouble("rating", 0.0),
                votes = show.optInt("votes", 0),
                traktId = next.optJSONObject("ids")?.optLong("trakt")?.takeIf { it > 0 },
                slug = null,
                showSlug = showSlug,
                season = next.optInt("season"),
                episode = next.optInt("number"),
                posterUrl = images,
                overview = next.optString("overview").ifBlank { show.optString("overview") },
                source = CandidateSource.CONTINUE
            )
        }
        out
    }

    private suspend fun watchedIds(clientId: String, token: String, type: String): Set<Long> = withContext(Dispatchers.IO) {
        val res = request("GET", "/sync/watched/$type?extended=min", clientId, token)
        val arr = JSONArray(res.body)
        buildSet {
            for (i in 0 until arr.length()) {
                val wrapper = arr.optJSONObject(i) ?: continue
                val obj = wrapper.optJSONObject(if (type == "movies") "movie" else "show") ?: continue
                val id = obj.optJSONObject("ids")?.optLong("trakt") ?: 0L
                if (id > 0) add(id)
            }
        }
    }

    private fun parseMovie(obj: JSONObject?, source: CandidateSource): MediaCandidate? {
        obj ?: return null
        val ids = obj.optJSONObject("ids")
        return MediaCandidate(
            kind = MediaKind.MOVIE,
            title = obj.optString("title").ifBlank { return null },
            year = obj.optInt("year").takeIf { it > 0 },
            runtimeMinutes = obj.optInt("runtime").takeIf { it > 0 },
            genres = stringSet(obj.optJSONArray("genres")),
            rating = obj.optDouble("rating", 0.0),
            votes = obj.optInt("votes", 0),
            traktId = ids?.optLong("trakt")?.takeIf { it > 0 },
            slug = ids?.optString("slug")?.takeIf { it.isNotBlank() },
            posterUrl = poster(obj),
            overview = obj.optString("overview").takeIf { it.isNotBlank() },
            source = source
        )
    }

    private fun parseShowAsEpisodeLike(obj: JSONObject?, source: CandidateSource): MediaCandidate? {
        obj ?: return null
        val ids = obj.optJSONObject("ids")
        return MediaCandidate(
            kind = MediaKind.EPISODE,
            title = obj.optString("title").ifBlank { return null },
            year = obj.optInt("year").takeIf { it > 0 },
            subtitle = if (source == CandidateSource.TRENDING || source == CandidateSource.WATCHLIST) "Start this series" else null,
            runtimeMinutes = obj.optInt("runtime").takeIf { it > 0 },
            genres = stringSet(obj.optJSONArray("genres")),
            rating = obj.optDouble("rating", 0.0),
            votes = obj.optInt("votes", 0),
            traktId = ids?.optLong("trakt")?.takeIf { it > 0 },
            showSlug = ids?.optString("slug")?.takeIf { it.isNotBlank() },
            posterUrl = poster(obj),
            overview = obj.optString("overview").takeIf { it.isNotBlank() },
            source = source
        )
    }

    private fun parseHistoryEpisode(wrapper: JSONObject?, source: CandidateSource): MediaCandidate? {
        wrapper ?: return null
        val episode = wrapper.optJSONObject("episode") ?: return null
        val show = wrapper.optJSONObject("show")
        val showTitle = show?.optString("title").orEmpty().ifBlank { episode.optString("title") }
        val showSlug = show?.optJSONObject("ids")?.optString("slug")?.takeIf { it.isNotBlank() }
        return MediaCandidate(
            kind = MediaKind.EPISODE,
            title = showTitle,
            year = show?.optInt("year")?.takeIf { it > 0 },
            subtitle = "S${episode.optInt("season")}E${episode.optInt("number")} · ${episode.optString("title")}",
            runtimeMinutes = episode.optInt("runtime").takeIf { it > 0 } ?: show?.optInt("runtime")?.takeIf { it > 0 },
            genres = stringSet(show?.optJSONArray("genres")),
            rating = show?.optDouble("rating", 0.0) ?: 0.0,
            votes = show?.optInt("votes", 0) ?: 0,
            traktId = episode.optJSONObject("ids")?.optLong("trakt")?.takeIf { it > 0 },
            showSlug = showSlug,
            season = episode.optInt("season"),
            episode = episode.optInt("number"),
            posterUrl = poster(show),
            overview = episode.optString("overview").ifBlank { show?.optString("overview").orEmpty() }.takeIf { it.isNotBlank() },
            source = source
        )
    }

    private fun parsePlaybackEpisode(wrapper: JSONObject?): MediaCandidate? {
        wrapper ?: return null
        return parseHistoryEpisode(wrapper, CandidateSource.PLAYBACK)?.copy(progress = wrapper.optDouble("progress").takeIf { !it.isNaN() })
    }

    private fun poster(obj: JSONObject?): String? {
        val raw = obj?.optJSONObject("images")?.optJSONArray("poster")?.optString(0).orEmpty()
        if (raw.isBlank()) return null
        return if (raw.startsWith("http")) raw else "https://$raw"
    }

    private fun stringSet(arr: JSONArray?): Set<String> = buildSet {
        if (arr == null) return@buildSet
        for (i in 0 until arr.length()) arr.optString(i).trim().lowercase().takeIf { it.isNotBlank() }?.let(::add)
    }

    private data class HttpResult(val code: Int, val body: String)

    private fun request(
        method: String,
        path: String,
        clientId: String,
        token: String?,
        body: JSONObject? = null,
        allowError: Boolean = false
    ): HttpResult {
        val conn = (URL(baseUrl + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15_000
            readTimeout = 20_000
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("trakt-api-version", "2")
            setRequestProperty("trakt-api-key", clientId)
            setRequestProperty("User-Agent", "CineClub/0.1.0 Android")
            token?.let { setRequestProperty("Authorization", "Bearer $it") }
            if (body != null) {
                doOutput = true
                outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
            }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.use { input -> BufferedReader(InputStreamReader(input)).readText() }.orEmpty()
        conn.disconnect()
        if (!allowError && code !in 200..299) {
            if (code == 401) throw IllegalStateException("Trakt session expired. Reconnect your account.")
            if (code == 429) throw IllegalStateException("Trakt rate limit reached. Try again shortly.")
            throw IllegalStateException("Trakt request failed ($code). ${text.take(180)}")
        }
        return HttpResult(code, text)
    }
}
