package com.cineclub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.cineclub.ui.CineClubApp
import com.cineclub.ui.CineClubTheme

class MainActivity : ComponentActivity() {
    private val vm: CineClubViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val state by vm.state.collectAsState()
            CineClubTheme { CineClubApp(vm, state) }
        }
    }
}
