package com.cineclub.data

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

object PosterCache {
    suspend fun load(context: Context, url: String): ImageBitmap? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.cacheDir, "trakt_posters").apply { mkdirs() }
            val name = MessageDigest.getInstance("SHA-256").digest(url.toByteArray()).joinToString("") { "%02x".format(it) }
            val file = File(dir, "$name.webp")
            if (!file.exists() || file.length() == 0L) {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 12_000
                conn.readTimeout = 15_000
                conn.setRequestProperty("User-Agent", "CineClub/0.1.0 Android")
                conn.inputStream.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                conn.disconnect()
            }
            BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap()
        }.getOrNull()
    }
}
