package com.cineclub.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tv
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cineclub.CineClubUiState
import com.cineclub.CineClubViewModel
import com.cineclub.data.PosterCache
import com.cineclub.model.*

@Composable
fun CineClubApp(vm: CineClubViewModel, state: CineClubUiState) {
    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
        if (!state.connected) ConnectScreen(vm, state) else TonightScreen(vm, state)
    }
}

@Composable
private fun ConnectScreen(vm: CineClubViewModel, state: CineClubUiState) {
    val context = LocalContext.current
    BoxWithConstraints(Modifier.fillMaxSize().padding(24.dp)) {
        val wide = maxWidth >= 760.dp
        val cardModifier = if (wide) Modifier.widthIn(max = 640.dp).align(Alignment.Center) else Modifier.fillMaxWidth().align(Alignment.Center)
        Column(cardModifier, verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("CINÉ CLUB", color = Purple, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Text("What should I watch next?", color = Color.White, fontSize = if (wide) 42.sp else 32.sp, fontWeight = FontWeight.Black)
            Text("V0.1 connects to your own Trakt account, reads only the watch data needed for recommendations, and returns three choices instead of another infinite feed.", color = Muted, fontSize = 16.sp, lineHeight = 23.sp)

            GlassCard {
                Text("Connect Trakt", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("For this private prototype, paste the Client ID from a Trakt developer app. No client secret is stored or required by Ciné Club.", color = Muted)
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = state.clientId,
                    onValueChange = vm::setClientId,
                    label = { Text("Trakt Client ID") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple, focusedLabelColor = Purple)
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = vm::beginConnect, enabled = !state.authBusy, colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Color.Black)) {
                        Text(if (state.authBusy && state.deviceCode == null) "Connecting…" else "Connect")
                    }
                    TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://developer.trakt.tv/"))) }) {
                        Text("Open Trakt Developer")
                    }
                }
            }

            state.deviceCode?.let { code ->
                GlassCard {
                    Text("Authorize this device", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(code.userCode, color = Purple, fontSize = 34.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 10.dp))
                    Text("Ciné Club is polling Trakt for approval. Open the Trakt verification page and enter the code above.", color = Muted)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(code.verificationUrl))) }) {
                        Icon(Icons.Rounded.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text("Open Trakt")
                    }
                }
            }
            ErrorText(state.error)
            Text("Prototype note: Trakt recommends PKCE for production mobile apps. V0.1 uses device authorization to avoid shipping a redirect-domain dependency while we validate the product.", color = Color(0xFF756E79), fontSize = 12.sp)
        }
    }
}

@Composable
private fun TonightScreen(vm: CineClubViewModel, state: CineClubUiState) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth >= 780.dp
        if (wide) {
            Row(Modifier.fillMaxSize().padding(20.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                FilterPanel(vm, state, Modifier.width(330.dp).fillMaxHeight())
                ResultsPane(vm, state, Modifier.weight(1f).fillMaxHeight(), wide = true)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item { FilterPanel(vm, state, Modifier.fillMaxWidth()) }
                item { ResultsPane(vm, state, Modifier.fillMaxWidth(), wide = false) }
            }
        }
    }
}

@Composable
private fun FilterPanel(vm: CineClubViewModel, state: CineClubUiState, modifier: Modifier) {
    val p = state.preferences
    Column(modifier, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CINÉ CLUB", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                Text("Tonight", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black)
                Text(state.connectedUser?.let { "Trakt · $it" } ?: "Trakt connected", color = Muted, fontSize = 13.sp)
            }
            IconButton(onClick = vm::disconnect) { Icon(Icons.Rounded.Settings, "Disconnect", tint = Muted) }
        }

        ChoiceSection("FORMAT") {
            EnumChips(FormatChoice.entries, p.format, { it.label }) { vm.setPreferences(p.copy(format = it)) }
        }
        ChoiceSection("TIME") {
            EnumChips(TimeChoice.entries, p.time, { it.label }) { vm.setPreferences(p.copy(time = it)) }
        }
        ChoiceSection("MOOD") {
            EnumChips(Mood.entries, p.mood, { it.label }) { vm.setPreferences(p.copy(mood = it)) }
        }
        ChoiceSection("COMPANY") {
            EnumChips(Company.entries, p.company, { it.label }) { vm.setPreferences(p.copy(company = it)) }
        }
        ChoiceSection("MODE") {
            EnumChips(WatchMode.entries, p.mode, { it.label }) { vm.setPreferences(p.copy(mode = it)) }
        }

        Button(
            onClick = vm::chooseTonight,
            enabled = !state.loading,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Color.Black),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text(if (state.loading) "Choosing…" else "Give me 3", fontWeight = FontWeight.Bold)
        }
        ErrorText(state.error)
        Text("No infinite feed. Three answers, then decide.", color = Color(0xFF756E79), fontSize = 12.sp)
    }
}

@Composable
private fun ResultsPane(vm: CineClubViewModel, state: CineClubUiState, modifier: Modifier, wide: Boolean) {
    val recs = state.recommendations
    if (recs.isEmpty()) {
        Box(modifier.clip(RoundedCornerShape(28.dp)).background(Glass).border(1.dp, Color(0xFF33263A), RoundedCornerShape(28.dp)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(30.dp)) {
                Text("3", color = Purple, fontSize = 72.sp, fontWeight = FontWeight.Black)
                Text("That’s the whole point.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Ciné Club will choose across movies and TV, using your Trakt history instead of making you browse another wall of posters.", color = Muted, modifier = Modifier.padding(top = 10.dp), lineHeight = 22.sp)
            }
        }
        return
    }

    if (wide) {
        Row(modifier, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            LazyColumn(Modifier.weight(0.43f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                itemsIndexed(recs) { index, rec -> RecommendationCard(rec, index == state.selectedIndex) { vm.select(index) } }
            }
            SelectedDetail(recs[state.selectedIndex.coerceIn(0, recs.lastIndex)], Modifier.weight(0.57f).fillMaxHeight(), scrollable = true)
        }
    } else {
        Column(modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            recs.forEachIndexed { index, rec ->
                RecommendationCard(rec, index == state.selectedIndex) { vm.select(index) }
                AnimatedVisibility(index == state.selectedIndex) { SelectedDetail(rec, Modifier.fillMaxWidth(), scrollable = false) }
            }
        }
    }
}

@Composable
private fun RecommendationCard(rec: Recommendation, selected: Boolean, onClick: () -> Unit) {
    val c = rec.candidate
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(if (selected) Glass2 else Glass)
            .border(1.dp, if (selected) Purple.copy(alpha = 0.75f) else Color(0xFF2B252E), RoundedCornerShape(22.dp))
            .clickable(onClick = onClick).padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Poster(c.posterUrl, Modifier.width(76.dp).aspectRatio(2f / 3f))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (c.kind == MediaKind.MOVIE) Icons.Rounded.Movie else Icons.Rounded.Tv, null, tint = Purple, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (c.kind == MediaKind.MOVIE) "MOVIE" else "TV", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Text(c.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            c.subtitle?.let { Text(it, color = Muted, fontSize = 13.sp, maxLines = 2) }
            val meta = listOfNotNull(c.year?.toString(), c.runtimeMinutes?.let { "$it min" }, c.rating.takeIf { it > 0 }?.let { "★ %.1f".format(it) }).joinToString("  ·  ")
            if (meta.isNotBlank()) Text(meta, color = Color(0xFF827A86), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun SelectedDetail(rec: Recommendation, modifier: Modifier, scrollable: Boolean) {
    val context = LocalContext.current
    val c = rec.candidate
    val scrollModifier = if (scrollable) Modifier.verticalScroll(rememberScrollState()) else Modifier
    Column(modifier.then(scrollModifier).clip(RoundedCornerShape(28.dp)).background(Glass).border(1.dp, Color(0xFF33263A), RoundedCornerShape(28.dp)).padding(18.dp)) {
        Poster(c.posterUrl, Modifier.fillMaxWidth().heightIn(min = 220.dp, max = 390.dp))
        Spacer(Modifier.height(16.dp))
        Text(c.title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
        c.subtitle?.let { Text(it, color = Purple, fontSize = 14.sp, modifier = Modifier.padding(top = 3.dp)) }
        c.overview?.let { Text(it, color = Muted, lineHeight = 21.sp, modifier = Modifier.padding(top = 12.dp)) }
        Spacer(Modifier.height(18.dp))
        Label("WHY THIS?")
        Text(rec.why, color = Color.White, lineHeight = 20.sp)
        Spacer(Modifier.height(14.dp))
        Label("RISK")
        Text(rec.risk, color = Muted, lineHeight = 20.sp)
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = {
                val url = c.traktUrl() ?: return@Button
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }, enabled = c.traktUrl() != null, colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Color.Black)) {
                Icon(Icons.Rounded.CheckCircle, null); Spacer(Modifier.width(7.dp)); Text("Open in Showly")
            }
            OutlinedButton(onClick = {
                val q = Uri.encode("${c.title} ${c.year ?: ""} trailer")
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$q")))
            }) {
                Icon(Icons.Rounded.PlayCircle, null); Spacer(Modifier.width(7.dp)); Text("Trailer")
            }
        }
        Text("Showly registers Trakt movie/show links. If Android has not associated the link with Showly yet, the same button opens Trakt in the browser instead.", color = Color(0xFF756E79), fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
private fun Poster(url: String?, modifier: Modifier) {
    val context = LocalContext.current
    var image by remember(url) { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    LaunchedEffect(url) { if (!url.isNullOrBlank()) image = PosterCache.load(context, url) }
    Box(modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF251B2B)), contentAlignment = Alignment.Center) {
        if (image != null) {
            Image(image!!, null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Rounded.Movie, null, tint = Purple.copy(alpha = 0.65f), modifier = Modifier.size(42.dp))
        }
    }
}

@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Glass).border(1.dp, Color(0xFF33263A), RoundedCornerShape(24.dp)).padding(18.dp), content = content)
}

@Composable
private fun ChoiceSection(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) { Label(title); content() }
}

@Composable
private fun Label(text: String) { Text(text, color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp) }

@Composable
private fun <T> EnumChips(values: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        itemsIndexed(values) { _, value ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label(value)) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple.copy(alpha = 0.2f), selectedLabelColor = Color.White))
        }
    }
}

@Composable
private fun ErrorText(error: String?) { if (!error.isNullOrBlank()) Text(error, color = Color(0xFFFF8A8A), fontSize = 13.sp) }
