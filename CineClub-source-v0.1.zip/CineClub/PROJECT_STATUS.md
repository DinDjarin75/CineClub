# Project Status — V0.1

Core loop implemented: connect Trakt → choose Tonight filters → fetch personal/public candidate pools → local ranking → exactly three picks → Showly/Trakt handoff.

Deliberately deferred: personal taste vocabulary, per-person company profiles, TMDB/JustWatch availability, Luxembourg cinema radar, incoming releases, PKCE production auth, ratings feedback loop, AI-written rationale, background sync.
