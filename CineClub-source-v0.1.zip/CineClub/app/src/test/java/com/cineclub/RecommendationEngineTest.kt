package com.cineclub

import com.cineclub.data.RecommendationEngine
import com.cineclub.model.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RecommendationEngineTest {
    private fun movie(id: Long, title: String, genres: Set<String>, runtime: Int, rating: Double = 7.5, source: CandidateSource = CandidateSource.TRENDING) =
        MediaCandidate(MediaKind.MOVIE, title, 2026, runtimeMinutes = runtime, genres = genres, rating = rating, votes = 1000, traktId = id, source = source)

    private fun episode(id: Long, title: String, genres: Set<String>, runtime: Int, source: CandidateSource = CandidateSource.CONTINUE) =
        MediaCandidate(MediaKind.EPISODE, title, 2026, runtimeMinutes = runtime, genres = genres, rating = 8.0, votes = 2000, traktId = id, source = source)

    @Test fun returnsAtMostThree() {
        val input = (1L..10L).map { movie(it, "M$it", setOf("horror"), 90) }
        assertEquals(3, RecommendationEngine.rank(input, WatchPreferences()).size)
    }

    @Test fun continueModeBoostsContinueCandidate() {
        val input = listOf(
            movie(1, "Popular", setOf("thriller"), 90, 9.5),
            episode(2, "Continue Me", setOf("thriller"), 45, CandidateSource.CONTINUE)
        )
        val ranked = RecommendationEngine.rank(input, WatchPreferences(mode = WatchMode.CONTINUE, mood = Mood.TENSE))
        assertEquals("Continue Me", ranked.first().candidate.title)
    }

    @Test fun movieFormatFiltersEpisodes() {
        val input = listOf(movie(1, "Film", setOf("comedy"), 90), episode(2, "Show", setOf("comedy"), 45))
        val ranked = RecommendationEngine.rank(input, WatchPreferences(format = FormatChoice.MOVIE, mood = Mood.FUNNY))
        assertTrue(ranked.all { it.candidate.kind == MediaKind.MOVIE })
    }
}
