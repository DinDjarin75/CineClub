package com.cineclub.model

enum class MediaKind { MOVIE, EPISODE }
enum class FormatChoice(val label: String) { MOVIE("Movie"), EPISODE("Episode"), EITHER("Either") }
enum class TimeChoice(val label: String, val maxMinutes: Int?) {
    SHORT("~45m", 55), QUICK("~90m", 105), FEATURE("~2h", 145), ANY("Any", null)
}
enum class Mood(val label: String) {
    WEIRD("Weird"), BRUTAL("Brutal"), TENSE("Tense"), FUNNY("Funny"), BEAUTIFUL("Beautiful"), MINDFUCK("Mindfuck"), COMFORT("Comfort")
}
enum class Company(val label: String) { ALONE("Alone"), ANAIS("Anaïs"), VAL("Val") }
enum class WatchMode(val label: String) { DISCOVERY("Discovery"), CONTINUE("Continue"), BLIND_SPOT("Blind spot"), REWATCH("Rewatch") }
enum class CandidateSource { TRENDING, CONTINUE, WATCHLIST, REWATCH, PLAYBACK }

data class WatchPreferences(
    val format: FormatChoice = FormatChoice.EITHER,
    val time: TimeChoice = TimeChoice.ANY,
    val mood: Mood = Mood.WEIRD,
    val company: Company = Company.ALONE,
    val mode: WatchMode = WatchMode.DISCOVERY
)

data class MediaCandidate(
    val kind: MediaKind,
    val title: String,
    val year: Int? = null,
    val subtitle: String? = null,
    val runtimeMinutes: Int? = null,
    val genres: Set<String> = emptySet(),
    val rating: Double = 0.0,
    val votes: Int = 0,
    val traktId: Long? = null,
    val slug: String? = null,
    val showSlug: String? = null,
    val season: Int? = null,
    val episode: Int? = null,
    val posterUrl: String? = null,
    val overview: String? = null,
    val source: CandidateSource = CandidateSource.TRENDING,
    val progress: Double? = null
) {
    fun traktUrl(): String? = when (kind) {
        MediaKind.MOVIE -> slug?.let { "https://trakt.tv/movies/$it" }
        MediaKind.EPISODE -> showSlug?.let { show ->
            if (season != null && episode != null) "https://trakt.tv/shows/$show/seasons/$season/episodes/$episode"
            else "https://trakt.tv/shows/$show"
        }
    }
}

data class Recommendation(
    val candidate: MediaCandidate,
    val score: Double,
    val why: String,
    val risk: String
)

data class DeviceCode(
    val deviceCode: String,
    val userCode: String,
    val verificationUrl: String,
    val expiresIn: Int,
    val interval: Int
)

data class TraktToken(val accessToken: String, val refreshToken: String? = null)
