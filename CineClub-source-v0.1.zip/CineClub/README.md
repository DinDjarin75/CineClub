# Ciné Club V0.1

**Question:** What should I watch next?

Ciné Club is deliberately not a Showly replacement. Showly/Trakt remain the tracking system of record; Ciné Club is the decision layer that returns exactly three choices across movies and TV.

## V0.1 scope

- Fold-aware black + purple Compose UI.
- Inputs: Movie / Episode / Either, time, mood, company, mode.
- Modes: Discovery, Continue, Blind spot, Rewatch.
- Trakt account connection via Device Code Flow for this private prototype.
- Reads Trakt trending, watched history, watchlist, playback and show progress endpoints.
- Local ranking engine returns at most 3 recommendations.
- Poster files are downloaded into the app cache before display (no image hotlink presentation).
- `Open in Showly` launches the Trakt item URL. Showly registers Trakt URLs as Android deep links; otherwise Android opens the browser.
- Trailer handoff to YouTube search.

## First-run setup

1. Create a Trakt API app in the Trakt Developer portal.
2. Copy its **Client ID**. Do **not** put a client secret in Ciné Club.
3. Launch Ciné Club and paste the Client ID.
4. Tap **Connect**, open the verification link, and approve the displayed device code.

Trakt's current guidance recommends Authorization Code + PKCE for production mobile apps. Device authorization is intentionally used only for V0.1 so we can validate the core product without first deploying a verified HTTPS App Link callback. A public release should migrate to PKCE.

## Privacy / storage

- V0.1 stores the Trakt Client ID and OAuth access token in the app's private Android SharedPreferences sandbox.
- No backend exists and Ciné Club sends no analytics.
- Cached Trakt images live in the app cache directory and can be cleared by Android.
- Disconnect clears the OAuth token locally.

## Trakt attribution

Ciné Club uses Trakt but is not endorsed or certified by Trakt.

## Build

CI expects Java 17, Android SDK 36, Build Tools 36.0.0 and Gradle 9.6.
