package com.cineclub.data

import android.content.Context

class SessionStore(context: Context) {
    private val prefs = context.getSharedPreferences("cineclub_session", Context.MODE_PRIVATE)

    var clientId: String?
        get() = prefs.getString("client_id", null)
        set(value) { prefs.edit().putString("client_id", value).apply() }

    var accessToken: String?
        get() = prefs.getString("access_token", null)
        set(value) { prefs.edit().putString("access_token", value).apply() }

    var refreshToken: String?
        get() = prefs.getString("refresh_token", null)
        set(value) { prefs.edit().putString("refresh_token", value).apply() }

    fun clearAuth() {
        prefs.edit().remove("access_token").remove("refresh_token").apply()
    }
}
